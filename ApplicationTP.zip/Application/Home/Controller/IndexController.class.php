<?php
namespace Home\Controller;

use Home\Controller\BaseController;

class IndexController extends BaseController {
    public function index()
    {
        $this->display();
    }
    public function top()
    {
        $this->display();
    }
    public function menu()
    {
        $this->display();
    }
    public function main()
    {
        $this->display();
    }
}