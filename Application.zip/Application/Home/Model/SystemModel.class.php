<?php
namespace Home\Model;
use Think\Model;
class SystemModel extends Model{
    protected $insertFields = array();
    protected $updateFields = array();
}